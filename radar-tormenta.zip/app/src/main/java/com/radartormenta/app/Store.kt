package com.radartormenta.app

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationManager
import org.json.JSONObject

data class Status(
    val level: Int,
    val headline: String,
    val detail: String,
    val conditions: String,
    val updatedAt: Long
) {
    fun toJson(): JSONObject = JSONObject()
        .put("level", level)
        .put("headline", headline)
        .put("detail", detail)
        .put("conditions", conditions)
        .put("updatedAt", updatedAt)

    companion object {
        fun fromJson(o: JSONObject) = Status(
            o.getInt("level"),
            o.getString("headline"),
            o.getString("detail"),
            o.getString("conditions"),
            o.getLong("updatedAt")
        )
    }
}

object Store {
    private fun p(ctx: Context) = ctx.getSharedPreferences("storm", Context.MODE_PRIVATE)

    fun saveLocation(ctx: Context, lat: Double, lon: Double) {
        p(ctx).edit().putString("lat", lat.toString()).putString("lon", lon.toString()).apply()
    }

    fun savedLocation(ctx: Context): Pair<Double, Double> {
        val lat = p(ctx).getString("lat", null)?.toDoubleOrNull() ?: -34.6037
        val lon = p(ctx).getString("lon", null)?.toDoubleOrNull() ?: -58.3816
        return Pair(lat, lon)
    }

    fun currentLocation(ctx: Context): Pair<Double, Double> {
        try {
            val ok = ctx.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
                ctx.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
            if (ok) {
                val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
                var best: Location? = null
                for (prov in lm.getProviders(true)) {
                    val l = try {
                        lm.getLastKnownLocation(prov)
                    } catch (e: SecurityException) {
                        null
                    }
                    if (l != null && (best == null || l.time > best.time)) best = l
                }
                if (best != null) {
                    saveLocation(ctx, best.latitude, best.longitude)
                    return Pair(best.latitude, best.longitude)
                }
            }
        } catch (e: Exception) {
        }
        return savedLocation(ctx)
    }

    fun alertKm(ctx: Context): Int = p(ctx).getInt("alertKm", 40)
    fun setAlertKm(ctx: Context, km: Int) = p(ctx).edit().putInt("alertKm", km).apply()

    fun alertsOn(ctx: Context): Boolean = p(ctx).getBoolean("alertsOn", true)
    fun setAlertsOn(ctx: Context, on: Boolean) = p(ctx).edit().putBoolean("alertsOn", on).apply()

    fun saveStatus(ctx: Context, s: Status) {
        p(ctx).edit().putString("status", s.toJson().toString()).apply()
    }

    fun loadStatus(ctx: Context): Status? {
        val raw = p(ctx).getString("status", null) ?: return null
        return try {
            Status.fromJson(JSONObject(raw))
        } catch (e: Exception) {
            null
        }
    }

    fun lastAlertLevel(ctx: Context): Int = p(ctx).getInt("lastAlertLevel", 0)
    fun lastAlertTime(ctx: Context): Long = p(ctx).getLong("lastAlertTime", 0L)
    fun setLastAlert(ctx: Context, level: Int, time: Long) {
        p(ctx).edit().putInt("lastAlertLevel", level).putLong("lastAlertTime", time).apply()
    }
}
